package com.cg.oiqgs.supportingClass;

import java.util.List;
import java.util.Scanner;

import com.cg.oiqgs.exception.OiqgsException;
import com.cg.oiqgs.mainclass.Agent;
import com.cg.oiqgs.mainclass.Insured;
import com.cg.oiqgs.mainclass.UnderWriter;
import com.cg.oiqgs.model.Policy;
import com.cg.oiqgs.service.InsuranceQuotesService;
import com.cg.oiqgs.serviceImpl.InsuranceQuotesServiceImpl;

public class ViewPolicy {
	static String userName;
	static String roleCode;

	@SuppressWarnings({ "resource", "unused", "static-access" })
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		InsuranceQuotesService service = new InsuranceQuotesServiceImpl();

		try {
			List<Policy> list = null;
			if (roleCode.equalsIgnoreCase("Agent") || roleCode.equalsIgnoreCase("Insured"))
				list = service.getPolicyDetails(userName);
			else if (roleCode.equalsIgnoreCase("Admin"))
				list = service.getPolicyDetails();

			if (!(list.isEmpty())) {
				System.out.println("POLICY NUMBER" + "		" + "BUSINESS SEGMENT" + "		" + "POLICY PREMIUM"
						+ "		" + "ACCOUNT NUMBER");
				for (Policy policy : list) {
					System.out.println(policy.getPolicyNumber() + "		" + policy.getBussinessSegment() + "		"
							+ policy.getPolicyPremium() + "		" + policy.getAccountNumber());
				}
			} else
				System.err.println("NO policy is created for this profile..contact admin to create policy ");
		} catch (OiqgsException e) {
			e.printStackTrace();
		}finally {
			System.out.println("Do you want to continue.....(y/n)");
			String choice = scanner.nextLine();
			if (roleCode.equalsIgnoreCase("Agent")) {
				if (choice.equalsIgnoreCase("y")) {
					Agent agent = new Agent();
					agent.main(null);
				} else
					System.exit(0);
			}
			if (roleCode.equalsIgnoreCase("Admin")) {
				if (choice.equalsIgnoreCase("y")) {
					UnderWriter underWriter = new UnderWriter();
					underWriter.main(null);
				} else
					System.exit(0);
			}
			if (roleCode.equalsIgnoreCase("Insured")) {
				if (choice.equalsIgnoreCase("y")) {
					Insured insured=new Insured();
					insured.main(null);
				} else
					System.exit(0);
			}
		}
	}

	public void getUserName(String user) {
		userName = user;
	}

	public void getRoleCode(String role) {
		roleCode = role;

	}

}
